import os

GFF_TEST_FILE=os.path.join(os.path.dirname(__file__),'test_gff.gff')
VCF_TEST_FILE=os.path.join(os.path.dirname(__file__),'test_vcf.vcf')
FRAME_TEST_FILE=os.path.join(os.path.dirname(__file__),'frame_test.txt')
VERSION_TEST_FILE=os.path.join(os.path.dirname(__file__),'v2_v3_map.txt')
